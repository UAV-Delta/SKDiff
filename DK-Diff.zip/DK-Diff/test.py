import numpy as np
import torch

'''
# 加载 .npz 文件
data = np.load('./pre_train/beijing_ukg_ER.npz')

# 查看文件中包含的数组名称
print("文件中的数组:", list(data.keys()))

# 查看 E_pretrain 数组的内容
E_pretrain = data['E_pretrain']
print("E_pretrain 数组形状:", E_pretrain.shape)
print("E_pretrain 数据类型:", E_pretrain.dtype)
print("E_pretrain 前几个元素:", E_pretrain[:5])  # 查看前5个元素

# 关闭文件
data.close()
'''

'''
state_dict = torch.load("ddpm_model.pth", map_location="cpu")

# 查看 state_dict 的 key
print(state_dict.keys())

# 查看某一层权重的形状
for k, v in state_dict.items():
    print(k, v.shape)
'''
'''
import pandas as pd

def extract_station_embeddings_by_city(df, city):
    """
    提取指定城市的 station_id 和 embedding 为字典
    :param df: 包含数据的 DataFrame
    :param city: 城市名称（如 "beijing"）
    :return: 字典，格式为 {station_id: embedding}
    """
    # 筛选包含指定城市的 file_name 行
    filtered_df = df[df['file_name'].str.contains(city, case=False, na=False)]
    
    # 提取 station_id 和 embedding 列，并转换为字典
    result_dict = dict(zip(filtered_df['station_id'], filtered_df['embedding']))
    
    return result_dict

# 示例调用：
# 假设你的数据已经读入为 df
# beijing_stations = extract_station_embeddings_by_city(df, "beijing")
# print(beijing_stations)

df = pd.read_excel("combined_data_with_embeddings.xlsx")
beijing_dict = extract_station_embeddings_by_city(df, "beijing")
print(beijing_dict.keys())
'''

import json
import numpy as np

# 读取城市嵌入数据
with open('city_embeddings.json', 'r', encoding='utf-8') as f:
    city_embeddings = json.load(f)

# 获取所有城市名称
cities = list(city_embeddings.keys())
print("所有城市:", cities)

# 前6个城市
first_six_cities = cities[:6]
# 后4个城市
last_four_cities = cities[-4:]

print(f"\n前6个城市: {first_six_cities}")
print(f"后4个城市: {last_four_cities}")

# 将嵌入向量转换为numpy数组
embeddings = {city: np.array(embedding) for city, embedding in city_embeddings.items()}

# 计算相似性分数的函数
def calculate_similarity(embedding1, embedding2):
    """
    计算两个城市嵌入向量的相似性分数
    λ_i^c = max(tanh(h_i^T h_j), 0)
    """
    dot_product = np.dot(embedding1, embedding2)
    tanh_value = np.tanh(dot_product)
    return max(tanh_value, 0)

# 计算所有组合的相似性分数
similarity_scores = {}

for city1 in first_six_cities:
    similarity_scores[city1] = {}
    for city2 in last_four_cities:
        score = calculate_similarity(embeddings[city1], embeddings[city2])
        similarity_scores[city1][city2] = score

# 打印结果
print("\n相似性分数矩阵:")
print("=" * 60)
print(f"{'':<12}", end="")
for city in last_four_cities:
    print(f"{city:<12}", end="")
print()

for city1 in first_six_cities:
    print(f"{city1:<12}", end="")
    for city2 in last_four_cities:
        print(f"{similarity_scores[city1][city2]:<12.6f}", end="")
    print()

# 计算每个前6城市对后4城市的平均相似度
print("\n每个城市对后4城市的平均相似度:")
print("=" * 40)
for city in first_six_cities:
    avg_score = np.mean([similarity_scores[city][c] for c in last_four_cities])
    print(f"{city}: {avg_score:.6f}")

# 找出最相似的城市对
max_similarity = 0
most_similar_pair = (None, None)

for city1 in first_six_cities:
    for city2 in last_four_cities:
        if similarity_scores[city1][city2] > max_similarity:
            max_similarity = similarity_scores[city1][city2]
            most_similar_pair = (city1, city2)

print(f"\n最相似的城市对: {most_similar_pair[0]} - {most_similar_pair[1]}")
print(f"相似度分数: {max_similarity:.6f}")


