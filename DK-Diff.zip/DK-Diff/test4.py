import torch.nn as nn
import torch
import torch.nn.functional as F
import random 
import numpy as np


LR = 0.01
SEED = 42

outputs = torch.tensor([[1,2,3],[2,3,4],[5,5,6]], dtype = torch.float32)
labels = torch.tensor([1,0,2])

# manual input: value, label: class
def maual_cross_entropy(outputs, labels):
    softmax = torch.softmax(outputs,dim=1)
    loss = 0
    for i in range(len(labels)):
        true_class = labels[i]
        prob = softmax[i, true_class]
        loss += -torch.log(prob)

    return loss/len(labels)

criterion = nn.CrossEntropyLoss()
loss = criterion(outputs, labels)
print(loss)

loss_manual_version = maual_cross_entropy(outputs, labels)
print(loss_manual_version)

def manual_cross_entropy(outputs, labels):
    softmax = torch.softmax(outputs, dim=1)
    for i in len(labels):
        true_class = labels[i]
        prob = softmax[i, true_class]
        loss += -torch.log(prob)
    return loss/len(labels)

# simple CNN
class SimpleCNN(nn.Module):
    def __init__(self):
        super().__init__()
        self.conv1 = nn.Conv2d(1,32, kernel_size=3, padding=1)
        self.bn1 = nn.BatchNorm1d(32)
        self.conv2 = nn.Conv2d(32, 64, kernel_size=3, padding=1)
        self.bn2 = nn.BatchNorm1d(64)
        self.pool = nn.MaxPool2d(2,2)

        self.fc1 = nn.Linear(64*14*14, 128)
        self.fc2 = nn.Linear(128, 10)

    def forward(self, x):
        x = F.relu(self.bn1(self.conv1(x)))
        x = F.relu(self.bn2(self.conv2(x)))
        x = self.pool(x)
        x = x.view(x.size(0),-1)
        x = F.relu(self.fc1(x))
        x = self.fc2(x)
        return x

DEVICE = torch.device("cuda" if torch.cuda.is_available() else "cpu")

DEVICE = torch.device("cuda" if torch.cuda.is_available() else "cpu")

class SimpleCNN(nn.Module):
    def __init__(self):
        super().__init__()
        self.conv1 = nn.Conv2d(1,32, kernel_size=3, padding=1)
        self.bn1 = nn.BatchNorm1d(32)
        self.conv2 = nn.Conv2d(32, 64, kernel_size=3, padding=1)
        self.bn2 = nn.BatchNorm1d(64)
        self.pool = nn.MaxPool2d(2,2)

        self.fc1 = nn.Linear(64*14*14, 128)
        self.fc2 = nn.Linear(128, 10)

    def forward(self,x):
        x = F.ReLu(self.bn1(self.conv1(x)))
        x = F.ReLu(self.bn2(self.conv2(x)))
        x = self.pool(x)
        x = x.view(x.size(0), -1)
        x = F.relu(self.fc1(x))
        x = self.fc2(x)
        return x
    
model = SimpleCNN().to(DEVICE)
optimizer = torch.optim.Adam(model.parameters(), lr=LR)

def set_seed(seed=SEED):
    random.seed(seed)
    np.random.random(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)

def set_seed(seed=SEED):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)

from torchvision import transforms
from PIL import Image

img = Image.open("method.jpg")
transform = transforms.ToTensor()
tensor_img = transform(img)
print(tensor_img.dtype)
print(tensor_img)