import pandas as pd
import json
import os

def excel_to_geojson_advanced(excel_file, output_file, sheet_name=0):
    """
    增强版：将Excel文件转换为GeoJSON格式，用于Mapbox可视化
    
    Parameters:
    excel_file: Excel文件路径
    output_file: 输出的GeoJSON文件路径
    sheet_name: 工作表名称或索引，默认为第一个工作表
    """
    
    try:
        # 检查文件是否存在
        if not os.path.exists(excel_file):
            raise FileNotFoundError(f"Excel文件不存在: {excel_file}")
        
        # 读取Excel文件
        df = pd.read_excel(excel_file, sheet_name=sheet_name)
        
        print(f"成功读取Excel文件，共 {len(df)} 行数据")
        
        # 创建GeoJSON结构
        geojson = {
            "type": "FeatureCollection",
            "features": []
        }
        
        valid_count = 0
        invalid_count = 0
        
        # 遍历每一行数据
        for index, row in df.iterrows():
            try:
                # 检查必要的列是否存在
                required_columns = ['lng', 'lat', 'code', 'score']
                if not all(col in df.columns for col in required_columns):
                    missing_cols = [col for col in required_columns if col not in df.columns]
                    raise ValueError(f"缺少必要的列: {missing_cols}")
                
                # 确保经纬度数据有效
                if (pd.notna(row['lng']) and pd.notna(row['lat']) and 
                    row['lng'] != '' and row['lat'] != ''):
                    
                    # 转换数据类型
                    lng = float(row['lng'])
                    lat = float(row['lat'])
                    
                    # 验证经纬度范围（中国大致范围）
                    if 73 <= lng <= 135 and 18 <= lat <= 54:
                        feature = {
                            "type": "Feature",
                            "geometry": {
                                "type": "Point",
                                "coordinates": [lng, lat]
                            },
                            "properties": {
                                "code": str(row['code']),
                                "score": float(row['score']) if pd.notna(row['score']) else 0.0,
                                "index": int(index)  # 添加索引便于追踪
                            }
                        }
                        geojson["features"].append(feature)
                        valid_count += 1
                    else:
                        print(f"警告: 第 {index} 行经纬度超出合理范围: ({lng}, {lat})")
                        invalid_count += 1
                else:
                    invalid_count += 1
                    
            except Exception as e:
                print(f"处理第 {index} 行时出错: {e}")
                invalid_count += 1
                continue
        
        # 保存为JSON文件
        with open(output_file, 'w', encoding='utf-8') as f:
            json.dump(geojson, f, ensure_ascii=False, indent=2)
        
        print(f"\n转换完成!")
        print(f"有效点位: {valid_count} 个")
        print(f"无效点位: {invalid_count} 个")
        print(f"GeoJSON文件已保存至: {output_file}")
        
        return geojson
        
    except Exception as e:
        print(f"转换过程中出错: {e}")
        return None

# 使用示例
if __name__ == "__main__":
    # 转换Excel文件
    excel_file = "location.xlsx"
    output_file = "beijing_nanjing_location.geojson"
    
    print("开始转换Excel文件到GeoJSON...")
    result = excel_to_geojson_advanced(excel_file, output_file)
    
    if result:
        print(f"\n转换成功！共生成 {len(result['features'])} 个点位")
        
        # 显示前几个点位的坐标范围
        if result["features"]:
            lngs = [feature["geometry"]["coordinates"][0] for feature in result["features"]]
            lats = [feature["geometry"]["coordinates"][1] for feature in result["features"]]
            
            print(f"经度范围: {min(lngs):.4f} - {max(lngs):.4f}")
            print(f"纬度范围: {min(lats):.4f} - {max(lats):.4f}")
            
            # 显示前3个点位作为示例
            print("\n前3个点位示例:")
            for i, feature in enumerate(result["features"][:3]):
                coords = feature["geometry"]["coordinates"]
                props = feature["properties"]
                print(f"点位 {i+1}: 坐标({coords[0]:.4f}, {coords[1]:.4f}), "
                      f"编码: {props['code']}, 分数: {props['score']:.4f}")