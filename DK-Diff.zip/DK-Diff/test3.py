import pandas as pd
import json

def generate_geojson_from_excel(file_path, output_path):
    """
    从Excel文件生成Mapbox可用的GeoJSON文件
    
    Args:
        file_path: Excel文件路径
        output_path: 输出的GeoJSON文件路径
    """
    
    # 读取Excel文件
    df = pd.read_excel(file_path)
    
    # 创建GeoJSON结构
    geojson = {
        "type": "FeatureCollection",
        "features": []
    }
    
    # 遍历每一行数据
    for _, row in df.iterrows():
        # 创建特征
        feature = {
            "type": "Feature",
            "properties": {
                "code": str(row['code']),  # 确保code是字符串类型
                "non_zero": float(row['non_zero']),
                # 添加颜色分类属性，便于Mapbox样式设置
                "color_category": "high" if row['non_zero'] > 0.7 else "low"
            },
            "geometry": {
                "type": "Point",
                "coordinates": [float(row['lng']), float(row['lat'])]
            }
        }
        
        geojson['features'].append(feature)
    
    # 保存为JSON文件
    with open(output_path, 'w', encoding='utf-8') as f:
        json.dump(geojson, f, indent=2, ensure_ascii=False)
    
    print(f"GeoJSON文件已生成: {output_path}")
    print(f"总共有 {len(geojson['features'])} 个站点")
    
    # 统计分类信息
    high_count = sum(1 for feature in geojson['features'] 
                    if feature['properties']['non_zero'] > 0.7)
    low_count = len(geojson['features']) - high_count
    
    print(f"non_zero > 0.7 的站点数量: {high_count}")
    print(f"non_zero <= 0.7 的站点数量: {low_count}")

# 如果你想要一个更简洁的版本，只返回GeoJSON对象
def generate_geojson_object(df):
    """
    直接从DataFrame生成GeoJSON对象
    
    Args:
        df: 包含站点数据的DataFrame
    
    Returns:
        dict: GeoJSON对象
    """
    features = []
    
    for _, row in df.iterrows():
        feature = {
            "type": "Feature",
            "properties": {
                "code": str(row['code']),
                "non_zero": float(row['non_zero']),
                "color_category": "high" if row['non_zero'] > 0.7 else "low"
            },
            "geometry": {
                "type": "Point",
                "coordinates": [float(row['lng']), float(row['lat'])]
            }
        }
        features.append(feature)
    
    return {
        "type": "FeatureCollection",
        "features": features
    }

# 使用示例
if __name__ == "__main__":
    # 方法1: 从Excel文件生成GeoJSON文件
    generate_geojson_from_excel('./hohhot_station.xlsx', 'hohhot_stations.geojson')
    
    # 方法2: 如果你已经将数据读入DataFrame
    # df = pd.read_excel('hohhot_station.xlsx')
    # geojson_obj = generate_geojson_object(df)
    
    # 保存为文件
    # with open('hohhot_stations.geojson', 'w') as f:
    #     json.dump(geojson_obj, f, indent=2)